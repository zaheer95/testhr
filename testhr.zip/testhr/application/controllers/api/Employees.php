<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Restserver\Libraries\REST_Controller;

class Employees extends REST_Controller
{
	public function index_get($id = null) {
		// TODO implement method
	}

	public function index_post() {
		// TODO implement method
	}
}
